new Swiper(".swiper-aside",{
    // initialSlide: 0,
    nextButton: ".swiper-aside-next",
    prevButton: ".swiper-aside-prev",
    slidesPerView: 2,
    height: 600,
    autoHeight: true,
    direction: 'vertical'
    /*breakpoints: {
        1024: {
            slidesPerView: 4,
            spaceBetween: 40
        },
        768: {
            slidesPerView: 3,
            spaceBetween: 30
        },
        640: {
            slidesPerView: 2,
            spaceBetween: 20
        },
        480: {
            slidesPerView: 1,
            spaceBetween: 10
        }
    }*/
})